# The pdf version of all of mentioned publications in the website.
